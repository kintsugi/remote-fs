class Settings:
    def __init__(self, filesystem=""):
        self.filesystem = filesystem
